// JavaScript Document
$(function(){

	$('.operate .more').click(function(){
		$(this).find('.PaymentRight').slideToggle();
	});
	
});

